package com.cryptoprices.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
